
class ContaPoupanca extends Conta {
    private double saldo;

    public ContaPoupanca(String titular) {
        super(titular);
        this.saldo = 0;
    }

    public double getSaldo() {
        return saldo;
    }

    public void realizarDeposito(double valor) throws ValorNegativoException {
        if (valor < 0) {
            throw new ValorNegativoException("Não é permitido realizar depósitos com valores negativos.");
        }

        this.saldo += valor;
        System.out.println("Depósito realizado com sucesso. Novo saldo: " + this.saldo);
    }

    public void realizarSaque(double valor) throws UnsupportedOperationException, SaldoInsuficienteException, ValorNegativoException {
        throw new UnsupportedOperationException("Não é possível realizar saques em conta poupança.");
    }

    public void realizarTransferencia(double valor, Conta contaDestino) throws UnsupportedOperationException, SaldoInsuficienteException, ValorNegativoException, TitularidadesDiferentesException {
        throw new UnsupportedOperationException("Não é possível realizar transferências a partir de conta poupança.");
    }

}








