
class SaldoInsuficienteException extends Exception {
    public SaldoInsuficienteException(String message) {
        super(message);
    }
}

class Banco {
    private double saldo;

    public Banco() {
        this.saldo = 0;
    }

    public double getSaldo() {
        return saldo;
    }

    public void realizarDeposito(double valor) throws ValorNegativoException {
        if (valor < 0) {
            throw new ValorNegativoException("Não é permitido realizar depósitos com valores negativos.");
        }

        this.saldo += valor;
        System.out.println("Depósito realizado com sucesso. Novo saldo: " + this.saldo);
    }

    public void realizarSaque(double valor) throws SaldoInsuficienteException, ValorNegativoException {
        if (valor < 0) {
            throw new ValorNegativoException("Não é permitido realizar saques com valores negativos.");
        }

        if (valor > saldo) {
            throw new SaldoInsuficienteException("Saldo insuficiente para realizar o saque. Saldo disponível: " + saldo);
        }

        this.saldo -= valor;
        System.out.println("Saque realizado com sucesso. Novo saldo: " + this.saldo);
    }

    public void realizarTransferencia(double valor, Banco contaDestino) throws SaldoInsuficienteException, ValorNegativoException {
        if (valor < 0) {
            throw new ValorNegativoException("Não é permitido realizar transferências com valores negativos.");
        }

        if (valor > saldo) {
            throw new SaldoInsuficienteException("Saldo insuficiente para realizar a transferência. Saldo disponível: " + saldo);
        }

        this.saldo -= valor;
        contaDestino.realizarDeposito(valor);
        System.out.println("Transferência realizada com sucesso. Novo saldo: " + this.saldo);
    }

	public void realizarDeposito(int valor) {
		
		
	}
}



