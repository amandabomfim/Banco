
class ValorNegativoException extends Exception {

	public ValorNegativoException(String message) {
        super(message);
    }

	
}

