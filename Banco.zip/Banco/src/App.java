
public class App {
    public static void main(String[] args) {
        Banco banco1 = new Banco();
        Banco banco2 = new Banco();
        ContaCorrente1 conta1 = new ContaCorrente1("João");
        ContaCorrente1 conta2 = new ContaCorrente1("Maria");
        ContaPoupanca conta3 = new ContaPoupanca("Pedro");

        try {
            conta1.realizarDeposito(100);
            conta1.realizarSaque(50);
            conta1.realizarTransferencia(70, conta2);
            conta1.realizarTransferencia(50, conta3); // Tentativa de transferência para conta poupança
        } catch (ValorNegativoException e) {
            System.out.println("Erro: " + e.getMessage());
        } catch (SaldoInsuficienteException e) {
            System.out.println("Erro: " + e.getMessage());
        } catch (TitularidadesDiferentesException e) {
            System.out.println("Erro: " + e.getMessage());
        }

        try {
            conta3.realizarSaque(50); // Tentativa de saque em conta poupança
        } catch (ValorNegativoException e) {
            System.out.println("Erro: " + e.getMessage());
        } catch (SaldoInsuficienteException e) {
            System.out.println("Erro: " + e.getMessage());
        } catch (UnsupportedOperationException e) {
            System.out.println("Erro: " + e.getMessage());
        }

        try {
            conta3.realizarTransferencia(50, conta1); // Tentativa de transferência a partir de conta poupança
        } catch (ValorNegativoException e) {
            System.out.println("Erro: " + e.getMessage());
        } catch (SaldoInsuficienteException e) {
            System.out.println("Erro: " + e.getMessage());
        } catch (TitularidadesDiferentesException e) {
            System.out.println("Erro: " + e.getMessage());
        } catch (UnsupportedOperationException e) {
            System.out.println("Erro: " + e.getMessage());
        }

    }
}
