
class ContaCorrente1 extends Conta {
    private double saldo;

    public ContaCorrente1(String titular) {
        super(titular);
        this.saldo = 0;
    }

    public void ContaCorrente(String titular) {
		
	}

	public double getSaldo() {
        return saldo;
    }

    public void realizarDeposito(double valor) throws ValorNegativoException {
        if (valor < 0) {
            throw new ValorNegativoException("Não é permitido realizar depósitos com valores negativos.");
        }

        this.saldo += valor;
        System.out.println("Depósito realizado com sucesso. Novo saldo: " + this.saldo);
    }

    public void realizarSaque(double valor) throws SaldoInsuficienteException, ValorNegativoException {
        if (valor < 0) {
            throw new ValorNegativoException("Não é permitido realizar saques com valores negativos.");
        }

        if (this instanceof ContaPoupanca) {
            throw new UnsupportedOperationException("Não é possível realizar saques em conta poupança.");
        }

        if (valor > saldo) {
            throw new SaldoInsuficienteException("Saldo insuficiente para realizar o saque. Saldo disponível: " + saldo);
        }

        this.saldo -= valor;
        System.out.println("Saque realizado com sucesso. Novo saldo: " + this.saldo);
    }

    public void realizarTransferencia(double valor, Conta contaDestino) throws SaldoInsuficienteException, ValorNegativoException, TitularidadesDiferentesException {
        if (valor < 0) {
            throw new ValorNegativoException("Não é permitido realizar transferências com valores negativos.");
        }

        if (!(contaDestino instanceof ContaCorrente1) || !contaDestino.titular.equals(this.titular)) {
            throw new TitularidadesDiferentesException("Não é permitido realizar transferências para contas com titularidades diferentes.");
        }

        if (valor > saldo) {
            throw new SaldoInsuficienteException("Saldo insuficiente para realizar a transferência. Saldo disponível: " + saldo);
        }

        this.saldo -= valor;
        ((ContaCorrente1) contaDestino).realizarDeposito(valor);
        System.out.println("Transferência realizada com sucesso. Novo saldo: " + this.saldo);
    }
}

