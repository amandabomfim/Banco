
class TitularidadesDiferentesException extends Exception {
    public TitularidadesDiferentesException(String message) {
        super(message);
    }
}