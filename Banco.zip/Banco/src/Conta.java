
class Conta {
    protected String titular;

    public Conta(String titular) {
        this.titular = titular;
    }
}